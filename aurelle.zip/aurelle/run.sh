#!/usr/bin/env bash
# Запуск: ./run.sh  → http://localhost:8080
# Настройки через переменные окружения: PORT, HOST, DATA_DIR, ADMIN_EMAIL, ADMIN_PASSWORD
cd "$(dirname "$0")"
[ -d out ] || ./build.sh
exec java -Dstdout.encoding=UTF-8 -cp out aurelle.Main
