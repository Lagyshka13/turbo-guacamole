# Aurelle Beauty System

Бэкенд на Java 21 (только JDK, без зависимостей) + фронтенд на HTML (`public/index.html`, стиль без изменений).

## Запуск
    ./build.sh
    ./run.sh          # http://localhost:8080

Нужен только JDK 21+. Данные лежат в `data/store.json`, фото — в `data/uploads/`.

Переменные окружения: `PORT`, `HOST`, `DATA_DIR`, `ADMIN_EMAIL` (по умолчанию admin@aurelle.local), `ADMIN_PASSWORD`.
Если пароль не задан, при первом запуске администратору создаётся случайный и печатается в консоль.

## API
| Метод | Путь | Доступ |
|---|---|---|
| GET | /api/modules, POST /api/modules/{i}/run | все |
| GET | /api/products | все |
| POST | /api/auth/register, /login, /logout | все |
| GET | /api/me | вход |
| GET/PUT/DELETE | /api/cart, /api/cart/{id} | вход |
| GET, POST | /api/favorites, /api/favorites/{id}/toggle | вход |
| GET/POST | /api/orders | вход |
| POST/PUT/DELETE | /api/admin/products[/{id}], /{id}/copy, /import, /reset | админ |
| POST | /api/admin/upload (тело — картинка) | админ |

Авторизация: `Authorization: Bearer <token>`. Пароли — PBKDF2-SHA256.
