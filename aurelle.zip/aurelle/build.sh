#!/usr/bin/env bash
# Сборка: нужен только JDK 21+ (внешние зависимости не используются).
set -e
cd "$(dirname "$0")"
rm -rf out && mkdir -p out
javac -encoding UTF-8 -d out src/aurelle/*.java
echo "Готово: out/"
