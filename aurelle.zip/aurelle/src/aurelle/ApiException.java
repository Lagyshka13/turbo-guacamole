package aurelle;

/** Ошибка с HTTP-статусом; текст уходит клиенту как {"error": "..."}. */
final class ApiException extends RuntimeException {
    final int status;

    ApiException(int status, String message) {
        super(message);
        this.status = status;
    }

    static ApiException bad(String m) { return new ApiException(400, m); }
    static ApiException unauthorized(String m) { return new ApiException(401, m); }
    static ApiException forbidden(String m) { return new ApiException(403, m); }
    static ApiException notFound(String m) { return new ApiException(404, m); }
    static ApiException conflict(String m) { return new ApiException(409, m); }
}
