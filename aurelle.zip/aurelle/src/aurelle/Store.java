package aurelle;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.*;
import java.util.regex.Pattern;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Хранилище данных магазина: пользователи, сессии, каталог, корзины, избранное, заказы. Сохраняется в JSON-файл. */
final class Store {
    record User(String name, String salt, String hash, String role) {}

    record Session(String email, long exp) {}

    static final Pattern EMAIL = Pattern.compile("^\\S+@\\S+\\.\\S+$");
    private static final long SESSION_MS = 30L * 24 * 3600 * 1000;
    private static final int PBKDF2_ITER = 120_000;
    private static final SecureRandom RND = new SecureRandom();

    private final Path file;
    private final Map<String, User> users = new LinkedHashMap<>();
    private final Map<String, Session> sessions = new HashMap<>();
    private final List<Map<String, Object>> products = new ArrayList<>();
    private final Map<String, Map<String, Integer>> carts = new HashMap<>();
    private final Map<String, List<String>> favs = new HashMap<>();
    private final Map<String, List<Map<String, Object>>> orders = new HashMap<>();
    private final Map<String, ArrayDeque<Long>> failures = new HashMap<>();
    private long idSeq = 0;

    Store(Path file) throws IOException {
        this.file = file;
        if (Files.exists(file)) load();
        else products.addAll(defaults());
    }

    // ---------- каталог по умолчанию ----------

    static List<Map<String, Object>> defaults() {
        Object[][] d = {
            {"d1", "Сыворотка с розой", "Уход", 2490, 0, "Увлажнение и сияние, 30 мл"},
            {"d2", "Крем с алоэ", "Уход", 1890, 1, "Лёгкий дневной крем, 50 мл"},
            {"d3", "Помада «Бархат»", "Макияж", 1290, 2, "Насыщенный матовый цвет"},
            {"d4", "Палетка теней", "Макияж", 2190, 3, "6 нейтральных оттенков"},
            {"d5", "Тоник-спрей", "Уход", 1190, 4, "Освежает и тонизирует, 100 мл"}};
        List<Map<String, Object>> l = new ArrayList<>();
        for (Object[] r : d) {
            Map<String, Object> p = new LinkedHashMap<>();
            p.put("s", 12);
            p.put("id", r[0]);
            p.put("n", r[1]);
            p.put("c", r[2]);
            p.put("p", r[3]);
            p.put("t", r[4]);
            p.put("d", r[5]);
            l.add(p);
        }
        return l;
    }

    // ---------- пароли и токены ----------

    private static String hex(byte[] b) {
        return HexFormat.of().formatHex(b);
    }

    private static String randomHex(int bytes) {
        byte[] b = new byte[bytes];
        RND.nextBytes(b);
        return hex(b);
    }

    private static String pbkdf2(String password, String saltHex) {
        try {
            KeySpec spec = new PBEKeySpec(password.toCharArray(), HexFormat.of().parseHex(saltHex), PBKDF2_ITER, 256);
            return hex(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded());
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private static String sha256(String s) {
        try {
            return hex(MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private String newSession(String email) {
        String token = randomHex(32);
        sessions.put(sha256(token), new Session(email, System.currentTimeMillis() + SESSION_MS));
        long now = System.currentTimeMillis();
        sessions.values().removeIf(s -> s.exp() < now);
        return token;
    }

    // ---------- пользователи ----------

    /** Создаёт администратора, если его ещё нет; true — если создан сейчас. */
    synchronized boolean ensureAdmin(String email, String password) {
        email = email.toLowerCase(Locale.ROOT);
        boolean has = users.values().stream().anyMatch(u -> u.role().equals("admin"));
        if (has) return false;
        String salt = randomHex(16);
        users.put(email, new User("Администратор", salt, pbkdf2(password, salt), "admin"));
        save();
        return true;
    }

    synchronized String register(String name, String email, String password) {
        name = name == null ? "" : name.trim();
        email = email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
        if (!EMAIL.matcher(email).matches() || email.length() > 120) throw ApiException.bad("Введите корректный email.");
        if (password == null || password.length() < 6) throw ApiException.bad("Пароль: минимум 6 символов.");
        if (password.length() > 200) throw ApiException.bad("Пароль слишком длинный.");
        if (name.isEmpty()) throw ApiException.bad("Введите имя.");
        if (name.length() > 60) throw ApiException.bad("Имя слишком длинное.");
        if (users.containsKey(email)) throw ApiException.conflict("Этот email уже зарегистрирован.");
        String salt = randomHex(16);
        users.put(email, new User(name, salt, pbkdf2(password, salt), "user"));
        String token = newSession(email);
        save();
        return token;
    }

    synchronized String login(String email, String password, String ip) {
        email = email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
        password = password == null ? "" : password;
        String key = email + "|" + ip;
        long now = System.currentTimeMillis();
        ArrayDeque<Long> f = failures.computeIfAbsent(key, k -> new ArrayDeque<>());
        while (!f.isEmpty() && now - f.peekFirst() > 10 * 60_000) f.pollFirst();
        if (f.size() >= 8) throw new ApiException(429, "Слишком много попыток. Попробуйте через несколько минут.");
        if (!EMAIL.matcher(email).matches()) throw ApiException.bad("Введите корректный email.");
        if (password.length() < 6) throw ApiException.bad("Пароль: минимум 6 символов.");
        User u = users.get(email);
        String got = pbkdf2(password, u == null ? "00" : u.salt());
        if (u == null || !MessageDigest.isEqual(got.getBytes(StandardCharsets.UTF_8), u.hash().getBytes(StandardCharsets.UTF_8))) {
            f.addLast(now);
            throw ApiException.unauthorized("Неверный email или пароль.");
        }
        failures.remove(key);
        String token = newSession(email);
        save();
        return token;
    }

    synchronized void logout(String token) {
        if (token != null && sessions.remove(sha256(token)) != null) save();
    }

    /** Email владельца токена или null. */
    synchronized String emailByToken(String token) {
        if (token == null || token.isEmpty()) return null;
        Session s = sessions.get(sha256(token));
        if (s == null) return null;
        if (s.exp() < System.currentTimeMillis() || !users.containsKey(s.email())) {
            sessions.remove(sha256(token));
            return null;
        }
        return s.email();
    }

    synchronized Map<String, Object> userView(String email) {
        User u = users.get(email);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("email", email);
        m.put("name", u.name());
        m.put("role", u.role());
        return m;
    }

    // ---------- каталог ----------

    synchronized List<Map<String, Object>> products() {
        List<Map<String, Object>> l = new ArrayList<>();
        for (Map<String, Object> p : products) l.add(new LinkedHashMap<>(p));
        return l;
    }

    private Map<String, Object> findProduct(String id) {
        for (Map<String, Object> p : products) if (p.get("id").equals(id)) return p;
        return null;
    }

    private String newId() {
        return "p" + System.currentTimeMillis() + (idSeq++);
    }

    /** Проверка и нормализация товара из запроса администратора. */
    static Map<String, Object> cleanProduct(Map<String, Object> in) {
        Object n = in.get("n"), p = in.get("p"), s = in.get("s"), c = in.get("c"), d = in.get("d"), img = in.get("img");
        String name = n instanceof String x ? x.trim() : "";
        if (name.isEmpty() || name.length() > 120) throw ApiException.bad("Укажите название (до 120 символов).");
        double price = p instanceof Number x ? x.doubleValue() : Double.NaN;
        if (!(price > 0) || price > 10_000_000) throw ApiException.bad("Укажите цену больше нуля.");
        Object stock = null;
        if (s != null) {
            if (!(s instanceof Number x) || x.doubleValue() != Math.rint(x.doubleValue()) || x.doubleValue() < 0 || x.doubleValue() > 1_000_000)
                throw ApiException.bad("Остаток: целое число от 0.");
            stock = ((Number) s).longValue();
        }
        String cat = c instanceof String x && !x.trim().isEmpty() ? x.trim() : "Без категории";
        String desc = d instanceof String x ? x.trim() : "";
        if (cat.length() > 60) throw ApiException.bad("Категория слишком длинная.");
        if (desc.length() > 500) throw ApiException.bad("Описание слишком длинное (до 500 символов).");
        String image = null;
        if (img instanceof String x && !x.isEmpty()) {
            if (!x.matches("/uploads/[a-f0-9]{32}\\.(png|jpg|gif|webp)")) throw ApiException.bad("Недопустимый адрес фото.");
            image = x;
        }
        Map<String, Object> o = new LinkedHashMap<>();
        o.put("n", name);
        o.put("p", p instanceof Long ? p : (Object) price);
        o.put("s", stock);
        o.put("c", cat);
        o.put("d", desc);
        o.put("img", image);
        return o;
    }

    synchronized List<Map<String, Object>> addProduct(Map<String, Object> in) {
        Map<String, Object> o = cleanProduct(in);
        Map<String, Object> p = new LinkedHashMap<>();
        p.put("id", newId());
        p.put("t", products.size() % 5);
        p.putAll(o);
        products.add(p);
        save();
        return products();
    }

    synchronized List<Map<String, Object>> updateProduct(String id, Map<String, Object> in) {
        Map<String, Object> p = findProduct(id);
        if (p == null) throw ApiException.notFound("Товар не найден.");
        p.putAll(cleanProduct(in));
        save();
        return products();
    }

    synchronized List<Map<String, Object>> deleteProduct(String id) {
        if (!products.removeIf(p -> p.get("id").equals(id))) throw ApiException.notFound("Товар не найден.");
        save();
        return products();
    }

    synchronized List<Map<String, Object>> copyProduct(String id) {
        Map<String, Object> p = findProduct(id);
        if (p == null) throw ApiException.notFound("Товар не найден.");
        Map<String, Object> c = new LinkedHashMap<>(p);
        c.put("id", newId());
        c.put("n", p.get("n") + " (копия)");
        products.add(c);
        save();
        return products();
    }

    synchronized List<Map<String, Object>> importProducts(Object in) {
        if (!(in instanceof List<?> l) || l.isEmpty() || l.size() > 1000) throw ApiException.bad("Неверный JSON каталога");
        List<Map<String, Object>> fresh = new ArrayList<>();
        int i = 0;
        for (Object x : l) {
            if (!(x instanceof Map<?, ?> m)) throw ApiException.bad("Неверный JSON каталога");
            @SuppressWarnings("unchecked") Map<String, Object> src = (Map<String, Object>) m;
            Map<String, Object> clean;
            try { clean = cleanProduct(src); } catch (ApiException e) { throw ApiException.bad("Неверный JSON каталога"); }
            Map<String, Object> p = new LinkedHashMap<>();
            p.put("id", newId());
            p.put("t", src.get("t") instanceof Number t && t.intValue() >= 0 && t.intValue() < 5 ? t.intValue() : 0);
            p.putAll(clean);
            fresh.add(p);
            i++;
        }
        products.clear();
        products.addAll(fresh);
        save();
        return products();
    }

    synchronized List<Map<String, Object>> resetProducts() {
        products.clear();
        products.addAll(defaults());
        save();
        return products();
    }

    // ---------- корзина ----------

    synchronized Map<String, Integer> cart(String email) {
        Map<String, Integer> c = carts.computeIfAbsent(email, k -> new LinkedHashMap<>());
        if (c.keySet().removeIf(id -> findProduct(id) == null)) save();
        return new LinkedHashMap<>(c);
    }

    synchronized Map<String, Integer> setCartQty(String email, String id, int qty) {
        Map<String, Object> p = findProduct(id);
        if (p == null) throw ApiException.notFound("Товар не найден.");
        Map<String, Integer> c = carts.computeIfAbsent(email, k -> new LinkedHashMap<>());
        if (qty <= 0) c.remove(id);
        else {
            if (p.get("s") instanceof Number s && qty > s.longValue()) throw ApiException.conflict("Больше нет в наличии");
            if (qty > 99) throw ApiException.bad("Слишком много единиц товара.");
            c.put(id, qty);
        }
        save();
        return cart(email);
    }

    // ---------- избранное ----------

    synchronized List<String> favorites(String email) {
        List<String> f = favs.computeIfAbsent(email, k -> new ArrayList<>());
        f.removeIf(id -> findProduct(id) == null);
        return new ArrayList<>(f);
    }

    synchronized List<String> toggleFavorite(String email, String id) {
        if (findProduct(id) == null) throw ApiException.notFound("Товар не найден.");
        List<String> f = favs.computeIfAbsent(email, k -> new ArrayList<>());
        if (!f.remove(id)) f.add(id);
        save();
        return favorites(email);
    }

    // ---------- заказы ----------

    synchronized List<Map<String, Object>> orders(String email) {
        return new ArrayList<>(orders.getOrDefault(email, List.of()));
    }

    synchronized Map<String, Object> placeOrder(String email) {
        Map<String, Integer> cart = cart(email);
        if (cart.isEmpty()) throw ApiException.bad("Корзина пуста.");
        double total = 0;
        List<String> items = new ArrayList<>();
        for (Map.Entry<String, Integer> e : cart.entrySet()) {
            Map<String, Object> p = findProduct(e.getKey());
            if (p.get("s") instanceof Number s && e.getValue() > s.longValue())
                throw ApiException.conflict("Недостаточно на складе: " + p.get("n"));
            total += ((Number) p.get("p")).doubleValue() * e.getValue();
            items.add(p.get("n") + " ×" + e.getValue());
        }
        for (Map.Entry<String, Integer> e : cart.entrySet()) {
            Map<String, Object> p = findProduct(e.getKey());
            if (p.get("s") instanceof Number s) p.put("s", s.longValue() - e.getValue());
        }
        long now = System.currentTimeMillis();
        Map<String, Object> o = new LinkedHashMap<>();
        o.put("id", String.format("%06d", now % 1_000_000));
        o.put("ts", now);
        o.put("total", total);
        o.put("items", String.join(", ", items));
        orders.computeIfAbsent(email, k -> new ArrayList<>()).add(0, o);
        carts.put(email, new LinkedHashMap<>());
        save();
        return o;
    }

    // ---------- сохранение ----------

    @SuppressWarnings("unchecked")
    private void load() throws IOException {
        Map<String, Object> root = Json.parseObject(Files.readString(file, StandardCharsets.UTF_8));
        for (Map.Entry<String, Object> e : ((Map<String, Object>) root.getOrDefault("users", Map.of())).entrySet()) {
            Map<String, Object> u = (Map<String, Object>) e.getValue();
            users.put(e.getKey(), new User((String) u.get("name"), (String) u.get("salt"), (String) u.get("hash"), (String) u.get("role")));
        }
        for (Map.Entry<String, Object> e : ((Map<String, Object>) root.getOrDefault("sessions", Map.of())).entrySet()) {
            Map<String, Object> s = (Map<String, Object>) e.getValue();
            sessions.put(e.getKey(), new Session((String) s.get("email"), ((Number) s.get("exp")).longValue()));
        }
        for (Object o : (List<Object>) root.getOrDefault("products", List.of())) products.add((Map<String, Object>) o);
        for (Map.Entry<String, Object> e : ((Map<String, Object>) root.getOrDefault("carts", Map.of())).entrySet()) {
            Map<String, Integer> c = new LinkedHashMap<>();
            for (Map.Entry<String, Object> x : ((Map<String, Object>) e.getValue()).entrySet()) c.put(x.getKey(), ((Number) x.getValue()).intValue());
            carts.put(e.getKey(), c);
        }
        for (Map.Entry<String, Object> e : ((Map<String, Object>) root.getOrDefault("favs", Map.of())).entrySet())
            favs.put(e.getKey(), new ArrayList<>((List<String>) e.getValue()));
        for (Map.Entry<String, Object> e : ((Map<String, Object>) root.getOrDefault("orders", Map.of())).entrySet())
            orders.put(e.getKey(), new ArrayList<>((List<Map<String, Object>>) e.getValue()));
    }

    private void save() {
        Map<String, Object> root = new LinkedHashMap<>();
        Map<String, Object> us = new LinkedHashMap<>();
        for (Map.Entry<String, User> e : users.entrySet()) {
            User u = e.getValue();
            us.put(e.getKey(), Map.of("name", u.name(), "salt", u.salt(), "hash", u.hash(), "role", u.role()));
        }
        Map<String, Object> ss = new LinkedHashMap<>();
        for (Map.Entry<String, Session> e : sessions.entrySet())
            ss.put(e.getKey(), Map.of("email", e.getValue().email(), "exp", e.getValue().exp()));
        root.put("users", us);
        root.put("sessions", ss);
        root.put("products", products);
        root.put("carts", carts);
        root.put("favs", favs);
        root.put("orders", orders);
        try {
            Files.createDirectories(file.toAbsolutePath().getParent());
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.writeString(tmp, Json.write(root), StandardCharsets.UTF_8);
            try {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            throw new UncheckedIOException("Не удалось сохранить данные", e);
        }
    }
}
