package aurelle;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;

/** HTTP-сервер Aurelle: REST API (/api/*), загруженные фото (/uploads/*) и статический фронтенд (public/). */
public final class Main {
    private static final int MAX_JSON = 2 * 1024 * 1024;
    private static final int MAX_UPLOAD = 5 * 1024 * 1024;
    private static final Map<String, String> TYPES = Map.of(
        "html", "text/html; charset=utf-8", "css", "text/css; charset=utf-8", "js", "text/javascript; charset=utf-8",
        "json", "application/json; charset=utf-8", "png", "image/png", "jpg", "image/jpeg", "gif", "image/gif",
        "webp", "image/webp", "svg", "image/svg+xml", "ico", "image/x-icon");

    private final Store store;
    private final Path publicDir, uploadDir;

    private Main(Store store, Path publicDir, Path uploadDir) {
        this.store = store;
        this.publicDir = publicDir.toAbsolutePath().normalize();
        this.uploadDir = uploadDir.toAbsolutePath().normalize();
    }

    public static void main(String[] args) throws Exception {
        String host = env("HOST", "0.0.0.0");
        int port = Integer.parseInt(env("PORT", "8080"));
        Path dataDir = Path.of(env("DATA_DIR", "data"));
        Path publicDir = Path.of(env("PUBLIC_DIR", "public"));
        Files.createDirectories(dataDir.resolve("uploads"));

        Store store = new Store(dataDir.resolve("store.json"));
        String adminEmail = env("ADMIN_EMAIL", "admin@aurelle.local");
        String adminPass = System.getenv("ADMIN_PASSWORD");
        boolean generated = adminPass == null || adminPass.length() < 6;
        if (generated) adminPass = randomPassword();
        boolean created = store.ensureAdmin(adminEmail, adminPass);
        if (created && generated)
            System.out.println("Создан администратор: " + adminEmail + " / " + adminPass + "  (сохраните пароль; свой можно задать через ADMIN_PASSWORD)");
        else if (created)
            System.out.println("Создан администратор: " + adminEmail);

        Main app = new Main(store, publicDir, dataDir.resolve("uploads"));
        HttpServer server = HttpServer.create(new InetSocketAddress(host, port), 0);
        server.createContext("/", app::handle);
        server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        server.start();
        System.out.println("Aurelle: http://localhost:" + port + "/  (данные: " + dataDir.toAbsolutePath() + ")");
    }

    private static String env(String k, String d) {
        String v = System.getenv(k);
        return v == null || v.isBlank() ? d : v;
    }

    private static String randomPassword() {
        String a = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        SecureRandom r = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 14; i++) sb.append(a.charAt(r.nextInt(a.length())));
        return sb.toString();
    }

    // ---------- диспетчер ----------

    private void handle(HttpExchange ex) throws IOException {
        try {
            String path = ex.getRequestURI().getPath();
            if (path.startsWith("/api/")) api(ex, path.substring(5));
            else if (path.startsWith("/uploads/")) serveFile(ex, uploadDir, path.substring(9), true);
            else serveFile(ex, publicDir, path.equals("/") ? "index.html" : path.substring(1), false);
        } catch (ApiException e) {
            json(ex, e.status, Map.of("error", e.getMessage()));
        } catch (IllegalArgumentException e) {
            json(ex, 400, Map.of("error", "Некорректный запрос: " + e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            json(ex, 500, Map.of("error", "Внутренняя ошибка сервера"));
        } finally {
            ex.close();
        }
    }

    private void api(HttpExchange ex, String path) throws IOException {
        String m = ex.getRequestMethod();
        String[] seg = path.split("/");
        String a = seg.length > 0 ? seg[0] : "";
        String b = seg.length > 1 ? seg[1] : null;
        String c = seg.length > 2 ? seg[2] : null;
        boolean two = seg.length == 2, three = seg.length == 3;

        // публичные
        if (a.equals("modules")) {
            if (m.equals("GET") && seg.length == 1) return200(ex, Map.of("modules", Modules.describe()));
            else if (m.equals("POST") && three && "run".equals(c)) {
                int i;
                try { i = Integer.parseInt(b); } catch (NumberFormatException e) { throw ApiException.notFound("Модуль не найден"); }
                Object vals = body(ex).get("values");
                @SuppressWarnings("unchecked") Map<String, Object> values = vals instanceof Map ? (Map<String, Object>) vals : Map.of();
                Modules.Res r = Modules.run(i, values);
                return200(ex, Map.of("cls", r.cls(), "text", r.text()));
            } else notAllowed();
            return;
        }
        if (a.equals("products") && seg.length == 1) {
            if (!m.equals("GET")) notAllowed();
            return200(ex, Map.of("products", store.products()));
            return;
        }
        if (a.equals("auth") && two) {
            switch (b) {
                case "register" -> {
                    need(m, "POST");
                    Map<String, Object> j = body(ex);
                    String token = store.register(str(j, "name"), str(j, "email"), str(j, "password"));
                    return200(ex, session(token));
                }
                case "login" -> {
                    need(m, "POST");
                    Map<String, Object> j = body(ex);
                    String ip = ex.getRemoteAddress().getAddress().getHostAddress();
                    return200(ex, session(store.login(str(j, "email"), str(j, "password"), ip)));
                }
                case "logout" -> {
                    need(m, "POST");
                    store.logout(token(ex));
                    return200(ex, Map.of("ok", true));
                }
                default -> throw ApiException.notFound("Не найдено");
            }
            return;
        }

        // нужна авторизация
        String email = store.emailByToken(token(ex));
        if (email == null) throw ApiException.unauthorized("Нужно войти в аккаунт.");

        switch (a) {
            case "me" -> {
                need(m, "GET");
                return200(ex, Map.of("user", store.userView(email)));
            }
            case "cart" -> {
                if (seg.length == 1) {
                    need(m, "GET");
                    return200(ex, Map.of("cart", store.cart(email)));
                } else if (two) {
                    if (m.equals("PUT")) {
                        Object q = body(ex).get("qty");
                        if (!(q instanceof Number n) || n.doubleValue() != Math.rint(n.doubleValue())) throw ApiException.bad("Неверное количество.");
                        return200(ex, Map.of("cart", store.setCartQty(email, b, (int) Math.max(-1, Math.min(1000, n.longValue())))));
                    } else if (m.equals("DELETE")) return200(ex, Map.of("cart", store.setCartQty(email, b, 0)));
                    else notAllowed();
                } else throw ApiException.notFound("Не найдено");
            }
            case "favorites" -> {
                if (seg.length == 1) {
                    need(m, "GET");
                    return200(ex, Map.of("favorites", store.favorites(email)));
                } else if (three && "toggle".equals(c)) {
                    need(m, "POST");
                    return200(ex, Map.of("favorites", store.toggleFavorite(email, b)));
                } else throw ApiException.notFound("Не найдено");
            }
            case "orders" -> {
                if (seg.length != 1) throw ApiException.notFound("Не найдено");
                if (m.equals("GET")) return200(ex, Map.of("orders", store.orders(email)));
                else if (m.equals("POST")) {
                    Map<String, Object> o = store.placeOrder(email);
                    Map<String, Object> r = new LinkedHashMap<>();
                    r.put("order", o);
                    r.put("cart", store.cart(email));
                    r.put("products", store.products());
                    return200(ex, r);
                } else notAllowed();
            }
            case "admin" -> admin(ex, m, seg, email);
            default -> throw ApiException.notFound("Не найдено");
        }
    }

    private void admin(HttpExchange ex, String m, String[] seg, String email) throws IOException {
        if (!"admin".equals(store.userView(email).get("role"))) throw ApiException.forbidden("Доступ только для администратора.");
        String b = seg.length > 1 ? seg[1] : "";
        if (b.equals("upload") && seg.length == 2) {
            need(m, "POST");
            return200(ex, Map.of("url", saveUpload(ex)));
            return;
        }
        if (!b.equals("products")) throw ApiException.notFound("Не найдено");
        String id = seg.length > 2 ? seg[2] : null;
        String act = seg.length > 3 ? seg[3] : null;
        if (id == null) {
            need(m, "POST");
            return200(ex, Map.of("products", store.addProduct(body(ex))));
        } else if (id.equals("import") && seg.length == 3) {
            need(m, "POST");
            Object raw;
            try { raw = Json.parse(new String(readBody(ex, MAX_JSON), StandardCharsets.UTF_8)); }
            catch (IllegalArgumentException e) { throw ApiException.bad("Неверный JSON каталога"); }
            return200(ex, Map.of("products", store.importProducts(raw)));
        } else if (id.equals("reset") && seg.length == 3) {
            need(m, "POST");
            return200(ex, Map.of("products", store.resetProducts()));
        } else if (seg.length == 3) {
            if (m.equals("PUT")) return200(ex, Map.of("products", store.updateProduct(id, body(ex))));
            else if (m.equals("DELETE")) return200(ex, Map.of("products", store.deleteProduct(id)));
            else notAllowed();
        } else if (seg.length == 4 && "copy".equals(act)) {
            need(m, "POST");
            return200(ex, Map.of("products", store.copyProduct(id)));
        } else throw ApiException.notFound("Не найдено");
    }

    // ---------- загрузка фото ----------

    private String saveUpload(HttpExchange ex) throws IOException {
        byte[] d = readBody(ex, MAX_UPLOAD);
        String ext = sniff(d);
        if (ext == null) throw ApiException.bad("Нужно изображение PNG, JPEG, GIF или WebP.");
        byte[] r = new byte[16];
        new SecureRandom().nextBytes(r);
        String name = java.util.HexFormat.of().formatHex(r) + "." + ext;
        Files.write(uploadDir.resolve(name), d);
        return "/uploads/" + name;
    }

    private static String sniff(byte[] d) {
        if (d.length > 8 && (d[0] & 0xff) == 0x89 && d[1] == 'P' && d[2] == 'N' && d[3] == 'G') return "png";
        if (d.length > 3 && (d[0] & 0xff) == 0xFF && (d[1] & 0xff) == 0xD8 && (d[2] & 0xff) == 0xFF) return "jpg";
        if (d.length > 6 && d[0] == 'G' && d[1] == 'I' && d[2] == 'F' && d[3] == '8') return "gif";
        if (d.length > 12 && d[0] == 'R' && d[1] == 'I' && d[2] == 'F' && d[3] == 'F' && d[8] == 'W' && d[9] == 'E' && d[10] == 'B' && d[11] == 'P') return "webp";
        return null;
    }

    // ---------- статика ----------

    private void serveFile(HttpExchange ex, Path root, String rel, boolean immutable) throws IOException {
        if (!ex.getRequestMethod().equals("GET") && !ex.getRequestMethod().equals("HEAD")) notAllowed();
        Path f;
        try { f = root.resolve(java.net.URLDecoder.decode(rel, StandardCharsets.UTF_8)).normalize(); }
        catch (Exception e) { throw ApiException.notFound("Не найдено"); }
        if (!f.startsWith(root) || !Files.isRegularFile(f)) throw ApiException.notFound("Не найдено");
        String name = f.getFileName().toString();
        String ext = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1).toLowerCase() : "";
        String type = TYPES.get(ext);
        if (type == null) throw ApiException.notFound("Не найдено");
        byte[] data = Files.readAllBytes(f);
        headers(ex);
        ex.getResponseHeaders().set("Content-Type", type);
        ex.getResponseHeaders().set("Cache-Control", immutable ? "public, max-age=31536000, immutable" : "no-cache");
        ex.sendResponseHeaders(200, ex.getRequestMethod().equals("HEAD") ? -1 : data.length);
        if (!ex.getRequestMethod().equals("HEAD")) try (OutputStream os = ex.getResponseBody()) { os.write(data); }
    }

    // ---------- вспомогательное ----------

    private static void headers(HttpExchange ex) {
        var h = ex.getResponseHeaders();
        h.set("X-Content-Type-Options", "nosniff");
        h.set("Referrer-Policy", "same-origin");
        h.set("X-Frame-Options", "DENY");
        h.set("Content-Security-Policy",
            "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'");
    }

    private static void need(String actual, String expected) {
        if (!actual.equals(expected)) notAllowed();
    }

    private static void notAllowed() {
        throw new ApiException(405, "Метод не поддерживается");
    }

    private static String token(HttpExchange ex) {
        String h = ex.getRequestHeaders().getFirst("Authorization");
        return h != null && h.startsWith("Bearer ") ? h.substring(7).trim() : null;
    }

    private static String str(Map<String, Object> j, String k) {
        return j.get(k) instanceof String s ? s : "";
    }

    private Map<String, Object> session(String token) {
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("token", token);
        r.put("user", store.userView(store.emailByToken(token)));
        return r;
    }

    private static byte[] readBody(HttpExchange ex, int limit) throws IOException {
        byte[] d = ex.getRequestBody().readNBytes(limit + 1);
        if (d.length > limit) throw new ApiException(413, "Слишком большой запрос (максимум " + limit / 1024 / 1024 + " МБ).");
        return d;
    }

    private static Map<String, Object> body(HttpExchange ex) throws IOException {
        byte[] d = readBody(ex, MAX_JSON);
        if (d.length == 0) return Map.of();
        return Json.parseObject(new String(d, StandardCharsets.UTF_8));
    }

    private static void return200(HttpExchange ex, Object o) throws IOException {
        json(ex, 200, o);
    }

    private static void json(HttpExchange ex, int status, Object o) throws IOException {
        byte[] d = Json.write(o).getBytes(StandardCharsets.UTF_8);
        headers(ex);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        ex.sendResponseHeaders(status, d.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(d); }
    }
}
