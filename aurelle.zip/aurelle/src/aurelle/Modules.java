package aurelle;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 25 учебных модулей «Aurelle Beauty System» (условия if / switch / && / || / !).
 * Описание полей отдаётся фронтенду, вся логика проверок выполняется здесь, на сервере.
 */
final class Modules {
    private Modules() {}

    record Field(String k, String l, String y, List<String> o) {}

    record Res(String cls, String text) {}

    record Mod(String g, String t, String op, String d, boolean menu, List<Field> f, Function<V, Res> run) {}

    /** Значения формы с типизированным доступом. */
    static final class V {
        private final Map<String, Object> m;
        private final Map<String, Field> fields = new LinkedHashMap<>();

        V(Map<String, Object> m, List<Field> f) {
            this.m = m;
            for (Field x : f) fields.put(x.k(), x);
        }

        /** Строковое значение; для select — только из разрешённого списка. */
        String s(String k) {
            Object o = m.get(k);
            String v = o == null ? "" : (o instanceof Boolean || o instanceof Map || o instanceof List ? "" : String.valueOf(o));
            if (v.length() > 200) v = v.substring(0, 200);
            Field f = fields.get(k);
            if (f != null && "s".equals(f.y()) && !f.o().contains(v)) return f.o().get(0);
            return v;
        }

        double n(String k) { return parseFloat(s(k)); }

        boolean b(String k) { return Boolean.TRUE.equals(m.get(k)); }
    }

    // ---------- helpers ----------

    private static final Pattern FLOAT = Pattern.compile("^\\s*[+-]?(\\d+\\.?\\d*|\\.\\d+)([eE][+-]?\\d+)?");

    /** Аналог parseFloat(str.replace(',', '.')) — берёт числовой префикс, иначе NaN. */
    static double parseFloat(String v) {
        Matcher mt = FLOAT.matcher(v.replace(',', '.'));
        if (!mt.find()) return Double.NaN;
        try { return Double.parseDouble(mt.group().trim()); } catch (NumberFormatException e) { return Double.NaN; }
    }

    /** Число как в тексте: 25 вместо 25.0. */
    static String f(double d) {
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return Long.toString((long) d);
        return BigDecimal.valueOf(d).stripTrailingZeros().toPlainString();
    }

    /** Аналог Number.toFixed. */
    static String fx(double d, int digits) {
        return new BigDecimal(d).setScale(digits, RoundingMode.HALF_UP).toPlainString();
    }

    private static Res ok(String t) { return new Res("ok", t); }
    private static Res warn(String t) { return new Res("warn", t); }
    private static Res err(String t) { return new Res("err", t); }
    private static Res info(String t) { return new Res("info", t); }

    private static Field t(String k, String l) { return new Field(k, l, "t", null); }
    private static Field p(String k, String l) { return new Field(k, l, "p", null); }
    private static Field n(String k, String l) { return new Field(k, l, "n", null); }
    private static Field c(String k, String l) { return new Field(k, l, "c", null); }
    private static Field s(String k, String l, String... o) { return new Field(k, l, "s", List.of(o)); }

    private static Mod mod(String g, String title, String op, String desc, List<Field> f, Function<V, Res> run) {
        return new Mod(g, title, op, desc, false, f, run);
    }

    private static final String[] LEVELS = {"обычный", "серебряный", "золотой"};

    private static int levelBonus(String level) {
        return level.equals("золотой") ? 10 : level.equals("серебряный") ? 5 : 0;
    }

    // ---------- каталог модулей ----------

    static final List<Mod> ALL = build();

    private static List<Mod> build() {
        List<Mod> L = new ArrayList<>();

        L.add(new Mod("Основы", "Главное меню", "меню", "Aurelle Beauty System: выберите функцию.", true, List.of(), null));

        L.add(mod(null, "Проверка ввода", "if / else", "Сколько товаров положить в корзину (1–10)?",
            List.of(t("x", "Количество")), v -> {
                String x = v.s("x");
                if (x.isBlank()) return err("Ошибка: пустое значение.");
                double n = parseFloat(x);
                if (Double.isNaN(n)) return err("Ошибка: это не число.");
                if (n < 1 || n > 10 || n % 1 != 0) return err("Ошибка: нужно целое от 1 до 10.");
                return ok("В корзину добавлено: " + f(n) + " шт.");
            }));

        L.add(mod(null, "Статус клиента", "if / else if / else", "Определяем статус аккаунта в магазине.",
            List.of(s("s", "Статус", "активный", "неактивный", "заблокированный")), v -> {
                String s = v.s("s");
                if (s.equals("активный")) return ok("Активный клиент: все функции и бонусы.");
                if (s.equals("неактивный")) return warn("Неактивный: подтвердите email для заказов.");
                return err("Заблокирован: обратитесь в поддержку.");
            }));

        L.add(mod(null, "Увлажнённость кожи", "if / else if", "Показатель прибора, 0–100%.",
            List.of(n("n", "Показатель, %")), v -> {
                double n = v.n("n");
                if (Double.isNaN(n) || n < 0 || n > 100) return err("Введите число 0–100.");
                if (n < 35) return err("Низкая (" + f(n) + "%): нужен увлажняющий крем.");
                if (n < 60) return warn("Нормальная (" + f(n) + "%): достаточно лёгкого ухода.");
                return ok("Высокая (" + f(n) + "%): кожа в отличном состоянии.");
            }));

        L.add(mod(null, "Вход в кабинет", "if / else + equals", "Подсказка: логин beauty, пароль 2026.",
            List.of(t("l", "Логин"), p("p", "Пароль")), v ->
                v.s("l").equals("beauty") && v.s("p").equals("2026")
                    ? ok("Добро пожаловать в личный кабинет!")
                    : err("Предупреждение: неверный логин или пароль.")));

        L.add(mod("Сложные условия", "Возрастной уход", "if / else if", "Категория ухода по возрасту.",
            List.of(n("a", "Возраст")), v -> {
                double a = v.n("a");
                if (Double.isNaN(a) || a < 10 || a > 100) return err("Некорректный возраст.");
                if (a < 18) return info("Подростковая линия: мягкое очищение, SPF.");
                if (a < 30) return info("Линия 18–29: увлажнение и защита.");
                if (a < 45) return info("Линия 30–44: антиоксиданты и ретинол.");
                return info("Линия 45+: лифтинг и питание.");
            }));

        L.add(mod(null, "Подарок-образец", "&&", "Образец дарим, если сумма ≥ 3000 ₽ И клиент в клубе.",
            List.of(n("s", "Сумма заказа"), c("c", "Участник клуба")), v ->
                v.n("s") >= 3000 && v.b("c")
                    ? ok("Образец сыворотки в подарок!")
                    : warn("Нужны оба условия: 3000 ₽ и членство.")));

        L.add(mod(null, "Статус «Beauty+»", "||", "Статус даётся при выполнении хотя бы одного условия.",
            List.of(c("a", "Заказов 5 и больше"), c("b", "День рождения на этой неделе"), c("c", "Отзыв с фото")), v ->
                v.b("a") || v.b("b") || v.b("c")
                    ? ok("Статус «Beauty+» назначен.")
                    : warn("Пока нет оснований для статуса.")));

        L.add(mod(null, "Можно оформлять заказ", "!", "Заказ разрешён, если аккаунт не заблокирован.",
            List.of(c("b", "Аккаунт заблокирован")), v ->
                !v.b("b") ? ok("Оформление заказа доступно.") : err("Оформление недоступно.")));

        L.add(mod(null, "Заказ в три шага", "вложенные if", "Три проверки подряд.",
            List.of(n("a", "Возраст"), c("z", "Нет аллергии на состав"), c("s", "Товар в наличии")), v -> {
                if (v.n("a") >= 18) {
                    if (v.b("z")) {
                        if (v.b("s")) return ok("Заказ подтверждён.");
                        return err("Шаг 3: товара нет в наличии.");
                    }
                    return err("Шаг 2: риск аллергии.");
                }
                return err("Шаг 1: нужен возраст 18+.");
            }));

        L.add(mod("Практика магазина", "Расчёт скидки", "if + switch", "Скидка зависит от суммы и статуса.",
            List.of(n("s", "Сумма покупки"), s("c", "Статус", LEVELS)), v -> {
                double s = v.n("s");
                if (Double.isNaN(s) || s < 0) return err("Введите сумму.");
                int p = s >= 10000 ? 10 : s >= 5000 ? 5 : 0;
                p += levelBonus(v.s("c"));
                return ok("Скидка " + p + "%\nК оплате: " + fx(s * (100 - p) / 100, 2) + " ₽");
            }));

        L.add(mod(null, "Бюджет на красоту", "if / else if", "Доля расходов на косметику от дохода.",
            List.of(n("i", "Доход в месяц"), n("e", "Траты на косметику")), v -> {
                double i = v.n("i"), e = v.n("e");
                if (!(i > 0) || Double.isNaN(e)) return err("Введите доход и траты.");
                double r = e / i * 100;
                if (r < 5) return ok("Умеренно: " + fx(r, 1) + "% дохода.");
                if (r <= 15) return warn("Заметно: " + fx(r, 1) + "%. Следите за бюджетом.");
                return err("Много: " + fx(r, 1) + "%. Стоит сократить покупки.");
            }));

        L.add(mod(null, "Тест консультанта", "if / else if", "Баллы за аттестацию, 0–100.",
            List.of(n("b", "Баллы")), v -> {
                double b = v.n("b");
                if (Double.isNaN(b) || b < 0 || b > 100) return err("Баллы от 0 до 100.");
                int g = b >= 90 ? 5 : b >= 75 ? 4 : b >= 50 ? 3 : 2;
                return g > 2 ? ok("Оценка: " + g + ". Аттестация пройдена.") : err("Оценка: " + g + ". Пересдача.");
            }));

        L.add(mod(null, "Риск аллергии", "&& / ||", "Уровень риска по нескольким параметрам.",
            List.of(n("a", "Аллергических реакций ранее"), c("s", "Чувствительная кожа"), c("n", "Новый для вас компонент")), v -> {
                double a = v.n("a");
                if (Double.isNaN(a)) a = 0;
                if (a >= 3 || (v.b("s") && v.b("n") && a >= 1)) return err("Высокий риск: нужна консультация дерматолога.");
                if (a >= 1 || v.b("s") || v.b("n")) return warn("Средний риск: сделайте тест на локтевом сгибе.");
                return ok("Низкий риск.");
            }));

        L.add(mod(null, "Подбор по типу кожи", "if / else if", "Один из нескольких вариантов решения.",
            List.of(s("t", "Тип кожи", "сухая", "жирная", "комбинированная", "чувствительная"),
                    s("p", "Проблема", "сухость", "высыпания", "морщины")), v -> {
                String t = v.s("t"), p = v.s("p");
                if (t.equals("сухая")) return info("Крем с алоэ и гиалуроновой кислотой.");
                if (t.equals("жирная")) return info(p.equals("высыпания") ? "Тоник с кислотами и гель-очиститель." : "Матирующий флюид.");
                if (t.equals("чувствительная")) return info("Мицеллярная вода и успокаивающий крем.");
                return info(p.equals("морщины") ? "Ночная сыворотка с ретинолом." : "Лёгкий увлажняющий гель.");
            }));

        L.add(mod("Разделы и switch", "Разделы магазина", "switch", "Переход между пятью разделами.",
            List.of(s("s", "Раздел", "1 Каталог", "2 Акции", "3 Корзина", "4 Консультация", "5 Контакты")), v -> {
                String s = v.s("s");
                switch (s.isEmpty() ? ' ' : s.charAt(0)) {
                    case '1': return info("Каталог: уход, макияж, парфюм.");
                    case '2': return info("Акции: 2+1 на маски, −20% на тени.");
                    case '3': return info("Корзина: ваши товары и промокод.");
                    case '4': return info("Консультация: чат с косметологом.");
                    case '5': return info("Контакты: адрес, телефон, соцсети.");
                    default: return err("Раздел не найден.");
                }
            }));

        L.add(mod(null, "Категория услуги", "switch", "Что доступно в выбранной категории.",
            List.of(s("c", "Категория", "Уход за лицом", "Макияж", "Парфюмерия", "Подарочные наборы")), v -> {
                switch (v.s("c")) {
                    case "Уход за лицом": return info("Кремы, сыворотки, маски, подбор по типу кожи.");
                    case "Макияж": return info("Тон, помады, тени. Виртуальная примерка.");
                    case "Парфюмерия": return info("Ароматы и пробники по 3 мл.");
                    default: return info("Готовые наборы и открытка с пожеланием.");
                }
            }));

        L.add(mod(null, "Калькулятор набора", "switch + if", "Тариф набора и доп. параметры.",
            List.of(s("t", "Набор", "Базовый", "Стандарт", "Люкс"), n("m", "Количество наборов"), c("g", "Подарочная упаковка (+300 ₽)")), v -> {
                double m = v.n("m");
                if (!(m > 0)) return err("Укажите количество.");
                double p;
                switch (v.s("t")) {
                    case "Базовый": p = 1500; break;
                    case "Стандарт": p = 3200; break;
                    default: p = 6000;
                }
                if (v.b("g")) p += 300;
                double tot = p * m;
                if (m >= 3) tot *= .9;
                return ok("Итого: " + fx(tot, 0) + " ₽" + (m >= 3 ? " (−10% за 3+ набора)" : ""));
            }));

        L.add(mod(null, "Обработка ошибок", "switch default", "Выберите пункт 1–5, иначе повторите.",
            List.of(t("c", "Пункт меню")), v -> {
                String c = v.s("c").trim();
                switch (c) {
                    case "1": case "2": case "3": case "4": case "5": return ok("Выбран пункт " + c + ".");
                    default: return err("Неверный выбор «" + v.s("c") + "». Повторите ввод.");
                }
            }));

        L.add(mod(null, "Всё вместе", "switch + if + &&", "Пять сценариев решений.",
            List.of(s("s", "Сценарий", "Промокод", "Возврат", "Доставка", "Рассрочка", "Лояльность"), n("n", "Значение (число)")), v -> {
                double n = v.n("n");
                if (Double.isNaN(n)) return err("Введите число.");
                switch (v.s("s")) {
                    case "Промокод": return n >= 2000 ? ok("Промокод действует: −10%.") : warn("Минимум 2000 ₽ в заказе.");
                    case "Возврат": return n <= 14 ? ok("Возврат возможен (до 14 дней).") : err("Срок возврата истёк.");
                    case "Доставка": return n >= 3000 ? ok("Бесплатная доставка.") : warn("Доставка 250 ₽.");
                    case "Рассрочка": return n >= 5000 && n <= 100000 ? ok("Рассрочка доступна.") : err("Сумма вне диапазона 5000–100 000 ₽.");
                    default: return n >= 10 ? ok("Золотой уровень лояльности.") : n >= 5 ? warn("Серебряный уровень.") : info("Базовый уровень.");
                }
            }));

        L.add(mod("Итоговый проект", "Модуль: уход за кожей", "5 условий", "Своя предметная область: подбор SPF и ухода.",
            List.of(n("u", "УФ-индекс сегодня"), n("o", "Время на улице (ч)"), c("s", "Чувствительная кожа"),
                    c("w", "Активный ретинол в уходе"), c("m", "Пользуетесь макияжем")), v -> {
                List<String> t = new ArrayList<>();
                double u = v.n("u");
                if (u >= 6) t.add("SPF 50+");
                else if (u >= 3) t.add("SPF 30");
                if (v.n("o") > 2) t.add("обновлять SPF каждые 2 часа");
                if (v.b("s")) t.add("минеральный фильтр без отдушек");
                if (v.b("w")) t.add("днём обязательно SPF");
                if (v.b("m")) t.add("вечером двойное очищение");
                return t.isEmpty() ? ok("Особых мер не нужно.") : warn("Рекомендации:\n• " + String.join("\n• ", t));
            }));

        L.add(mod(null, "Анализ состояния кожи", "5 параметров", "Пять показателей дают итог (0–10).",
            List.of(n("a", "Увлажнённость"), n("b", "Жирность"), n("c", "Эластичность"), n("d", "Тон и сияние"), n("e", "Покраснения")), v -> {
                double a = v.n("a"), b = v.n("b"), c = v.n("c"), d = v.n("d"), e = v.n("e");
                for (double x : new double[]{a, b, c, d, e})
                    if (Double.isNaN(x) || x < 0 || x > 10) return err("Все значения от 0 до 10.");
                double s = a + c + d + (10 - Math.abs(b - 5) * 2) + (10 - e);
                double p = s / 5;
                String note = p >= 7 ? ". Кожа в хорошем состоянии." : p >= 4.5 ? ". Нужен регулярный уход." : ". Нужна консультация косметолога.";
                return new Res(p >= 7 ? "ok" : p >= 4.5 ? "warn" : "err", "Итог: " + fx(p, 1) + " из 10" + note);
            }));

        L.add(mod(null, "Три уровня ухода", "if / else if", "Сколько шагов в вашем уходе?",
            List.of(n("h", "Шагов в уходе")), v -> {
                double h = v.n("h");
                if (Double.isNaN(h) || h < 0) return err("Введите число шагов.");
                if (h < 2) return err("Базовый уровень: добавьте крем и SPF.");
                if (h < 5) return warn("Средний уровень: хорошо, добавьте сыворотку.");
                return ok("Продвинутый уровень: следите за совместимостью.");
            }));

        L.add(mod(null, "Персональные советы", "комбинации условий", "Разные советы для разных сочетаний.",
            List.of(s("s", "Сезон", "зима", "лето"), s("k", "Кожа", "сухая", "жирная"), c("a", "Возраст 30+")), v -> {
                String s = v.s("s"), k = v.s("k");
                boolean a = v.b("a");
                if (s.equals("зима") && k.equals("сухая")) return info("Плотный крем с церамидами" + (a ? " и пептидами." : "."));
                if (s.equals("зима")) return info("Лёгкий крем и мягкий скраб.");
                if (k.equals("жирная")) return info("Матирующий SPF и гель для умывания.");
                return info("Увлажняющий флюид с SPF" + (a ? ", вечером ретинол." : "."));
            }));

        L.add(mod(null, "Итоговый отчёт", "всё вместе", "Оформление заказа и отчёт о решении системы.",
            List.of(t("n", "Имя клиента"), n("a", "Возраст"), n("s", "Сумма заказа"), c("b", "Аккаунт заблокирован"),
                    s("c", "Статус", LEVELS), c("z", "Есть аллергия на состав")), v -> {
                double a = v.n("a"), s = v.n("s");
                String name = v.s("n").trim();
                if (name.isEmpty() || Double.isNaN(a) || Double.isNaN(s)) return err("Заполните имя, возраст и сумму.");
                int p = s >= 5000 ? 5 : 0;
                p += levelBonus(v.s("c"));
                List<String> out = new ArrayList<>(List.of(
                    "Клиент: " + v.s("n"),
                    "Возраст: " + f(a),
                    "Сумма: " + f(s) + " ₽",
                    "Скидка: " + p + "%",
                    "Итого: " + fx(s * (100 - p) / 100, 2) + " ₽",
                    "Доставка: " + (s >= 3000 ? "бесплатно" : "250 ₽"),
                    ""));
                String d, cls;
                if (v.b("b")) { d = "Отказ: аккаунт заблокирован."; cls = "err"; }
                else if (a < 18) { d = "Отказ: нужно 18+."; cls = "err"; }
                else if (v.b("z")) { d = "Условно: нужна консультация по составу."; cls = "warn"; }
                else { d = "Заказ одобрен."; cls = "ok"; }
                out.add("РЕШЕНИЕ: " + d);
                return new Res(cls, String.join("\n", out));
            }));

        return List.copyOf(L);
    }

    // ---------- API ----------

    /** Метаданные для построения интерфейса (без логики). */
    static List<Map<String, Object>> describe() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Mod m : ALL) {
            Map<String, Object> o = new LinkedHashMap<>();
            if (m.g() != null) o.put("g", m.g());
            o.put("t", m.t());
            o.put("op", m.op());
            o.put("d", m.d());
            if (m.menu()) o.put("menu", 1);
            List<Object> fs = new ArrayList<>();
            for (Field x : m.f()) {
                Map<String, Object> fo = new LinkedHashMap<>();
                fo.put("k", x.k());
                fo.put("l", x.l());
                fo.put("y", x.y());
                if (x.o() != null) fo.put("o", x.o());
                fs.add(fo);
            }
            o.put("f", fs);
            out.add(o);
        }
        return out;
    }

    static Res run(int index, Map<String, Object> values) {
        if (index < 0 || index >= ALL.size()) throw ApiException.notFound("Модуль не найден");
        Mod m = ALL.get(index);
        if (m.run() == null) throw ApiException.bad("У этого модуля нет проверки");
        return m.run().apply(new V(values, m.f()));
    }
}
